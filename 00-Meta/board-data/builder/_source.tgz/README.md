# Open board builder

Rebuilds `https://claude.ai/code/artifact/de27b6c8-cbac-4342-a5cc-32e0598f6144`
from the five registers.

## Rebuild

    cd 00-Meta/board-data/builder
    VAULT="$HOME/mnt/My Brain" python3 build_board.py
    # -> open-board.html, publish it to the artifact URL above

## Never lose a comment

Austin comments on rows in the published page. Those comments live in the
page, not in the vault, so **every rebuild must carry them through**:

    # 1. save the LIVE artifact HTML to live.html (Claude reads it with the Artifact tool)
    python3 pull_comments.py live.html comments.json
    # 2. after writing a row's comments into its register, mark them done:
    python3 pull_comments.py live.html comments.json --action KP-0010 TD-0004
    # 3. rebuild - build_board.py picks up comments.json automatically
    VAULT="$HOME/mnt/My Brain" python3 build_board.py

Skipping step 1 wipes the history. There is no other copy of it.

## Files

| File | What it is |
|---|---|
| `parse_registers.py` | reads the five registers. **Header-driven**: every markdown table is mapped by its own header row, never by column position. The 2026-09-01 defect came from assuming a fixed order. |
| `build_board.py` | assembles the page: template + data block. |
| `template_head.html` | `<title>`, fonts, and the CSS (`__BOARD_CSS__` is filled from `board.css`). |
| `board.css` | the board's styles. |
| `template_app.js` | renders rows from the data block, filters, the comment popup, save. |
| `pull_comments.py` | extracts comment history out of a published page. |

## How the page republishes itself

The published page carries a base64 copy of its own template with two
markers, `__TPL_B64__` and `__DATA_JSON__`. Saving decodes the template,
puts the same base64 back in the first marker and the new data in the
second, and calls `artifact.publish`. The template is therefore a fixed
point: only the data block ever changes. `template_app.js` builds those
marker strings at runtime (`"__TPL" + "_B64__"`) so the builder's own
literal replacement does not corrupt the app source.
