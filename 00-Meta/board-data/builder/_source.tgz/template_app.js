"use strict";
/* The Open Board — rendered from data so the page can republish itself.
   Comment lifecycle: pending (this browser only) -> open (saved into the
   published page) -> actioned (Claude wrote it into the register). */

var BOARD = JSON.parse(document.getElementById("board").textContent);
var ROWS = BOARD.rows, META = BOARD.meta;
var COM = BOARD.comments || {};          /* id -> [{ts,text,state}] */
var DRAFT_KEY = "openboard.pending.v1";
var VIEW_KEY = "openboard.view.v1";

/* ---------- pending comments kept out of the published data ---------- */
var PEND = {};
try {
  var raw = localStorage.getItem(DRAFT_KEY);
  if (raw) PEND = JSON.parse(raw) || {};
} catch (e) { PEND = {}; }
function savePend() {
  try {
    if (Object.keys(PEND).length) localStorage.setItem(DRAFT_KEY, JSON.stringify(PEND));
    else localStorage.removeItem(DRAFT_KEY);
  } catch (e) {}
}
function pendCount() { var n = 0; for (var k in PEND) n += PEND[k].length; return n; }
function allFor(id) { return (COM[id] || []).concat(PEND[id] || []); }
function openFor(id) {
  return allFor(id).filter(function (c) { return c.state !== "actioned"; });
}

function trim(s, n) {
  s = String(s || "");
  if (s.length <= n) return s;
  var cut = s.slice(0, n), sp = cut.lastIndexOf(" ");
  return (sp > n * 0.6 ? cut.slice(0, sp) : cut) + "\u2026";
}
function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
  });
}
function stamp() {
  var d = new Date(), p = function (n) { return (n < 10 ? "0" : "") + n; };
  return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) +
         " " + p(d.getHours()) + ":" + p(d.getMinutes());
}

var PCLASS = { "Critical (stated)": "p-crit", "Awaiting your ruling": "p-rule",
  "High (stated)": "p-high", "High (ledger)": "p-high", "Blocked": "p-blok",
  "Decided, never actioned": "p-dna", "Open": "p-open", "Closed": "p-clos" };
var PLABEL = { "Critical (stated)": "Critical", "Awaiting your ruling": "Your ruling",
  "High (stated)": "High", "High (ledger)": "High", "Blocked": "Blocked",
  "Decided, never actioned": "Not done", "Open": "Open", "Closed": "Closed" };
var PORDER = ["Critical (stated)", "Awaiting your ruling", "High (stated)", "High (ledger)",
  "Blocked", "Decided, never actioned", "Open", "Closed"];

/* ---------------------------- render ---------------------------- */
function counts(field) {
  var c = {};
  ROWS.forEach(function (r) { var v = r[field]; if (v) c[v] = (c[v] || 0) + 1; });
  return c;
}
function msel(id, label, c, order) {
  var keys = (order || Object.keys(c).sort()).filter(function (k) { return c[k]; });
  var boxes = keys.map(function (k) {
    return '<label><input type="checkbox" value="' + esc(k) + '"><span>' + esc(k) +
           "</span><i>" + c[k] + "</i></label>";
  }).join("");
  return '<div class="ms" id="' + id + '"><button type="button" class="ms__btn">' + esc(label) +
    ' <span class="ms__sel">all</span><span class="ms__car"></span></button>' +
    '<div class="ms__panel" hidden><div class="ms__tools">' +
    '<button type="button" class="ms__all">All</button>' +
    '<button type="button" class="ms__none">None</button></div>' + boxes + "</div></div>";
}
function rowHTML(r, i) {
  var open = openFor(r.id), pend = (PEND[r.id] || []).length, tot = allFor(r.id).length;
  var cls = "row" + (pend ? " haspend" : (tot ? " hascom" : ""));
  var cb = '<button class="cbtn' + (pend ? " pend" : (tot ? " has" : "")) + '" data-c="' + esc(r.id) +
    '">Comment' + (tot ? " <i>" + tot + "</i>" : "") + "</button>";
  var src = '<button class="cpq" data-q="' + esc(r.q || "") + '">Copy search</button>' + cb;
  if (r.srcurl) src += '<a class="slink" href="' + esc(r.srcurl) + '" target="_blank" rel="noopener">source</a>';
  src += '<a class="sreg" href="' + esc(r.regurl) + '">register</a>';
  src += '<span class="age">' + (r.age ? r.age + "d" : "&mdash;") + "</span>";
  return '<div class="' + cls + '" data-i="' + i + '">' +
    '<div><span class="rid" title="Click to copy">' + esc(r.id) + "</span></div>" +
    '<div><span class="pill ' + (PCLASS[r.priority] || "p-open") + '">' +
      esc(PLABEL[r.priority] || r.priority) + "</span></div>" +
    '<div><div class="desc">' + esc(trim(r.desc, 230)) + '</div><div class="meta">' +
      esc(r.category) + " &middot; " + esc((r.state || "open").slice(0, 78)) +
      (r.lot ? " &middot; " + esc(r.lot) : "") + "</div></div>" +
    '<div class="own">' + esc(r.owner_short) + "</div>" +
    '<div class="srcs">' + src + "</div></div>";
}
function render() {
  var byReg = {}, regOrder = [];
  ROWS.forEach(function (r, i) {
    if (!byReg[r.reg]) { byReg[r.reg] = {}; regOrder.push(r.reg); }
    var s = r.sec || "Unfiled";
    (byReg[r.reg][s] = byReg[r.reg][s] || []).push(i);
  });
  var h = [];
  h.push('<p class="eyebrow">Parakeet Communities &middot; every open item &middot; ' + esc(META.built) + "</p>");
  h.push("<h1>" + META.total + " items, every one with an ID you can quote back to me.</h1>");
  h.push('<p class="lede">All five registers on one page. <b>' + META.open + " open, " + META.unowned +
    " with nobody's name on them.</b> Comment on any row and the note is kept here, date stamped, until it lands in the register.</p>");
  h.push(META.how || "");
  h.push('<div class="stats">' +
    '<div class="stat"><b>' + META.open + "</b><span>Open right now</span></div>" +
    '<div class="stat"><b style="color:var(--red)">' + META.unowned + "</b><span>No owner</span></div>" +
    '<div class="stat"><b style="color:var(--red)">' + META.hot + "</b><span>Critical, or waiting on your ruling</span></div>" +
    '<div class="stat"><b style="color:var(--green)">' + META.closed + "</b><span>Closed and kept visible</span></div>" +
    '<div class="stat"><b id="cmtot">0</b><span>Comments on the board</span></div></div>');
  h.push('<div class="bar"><div class="bar__row">' +
    '<input type="search" id="q" placeholder="Search text, owner, or an ID like PF-0324&hellip;" autocomplete="off">' +
    msel("fp", "Priority", counts("priority"), PORDER) +
    msel("fc", "Category", counts("category")) +
    msel("fm", "Community", counts("community")) +
    msel("fo", "Owner", counts("owner_short")) +
    '<label class="tog"><input type="checkbox" id="fu"> Unassigned only</label>' +
    '<label class="tog"><input type="checkbox" id="fk"> Commented only</label>' +
    '<button class="btn" id="reset">Reset</button>' +
    '<button class="btn" id="expand">Expand all</button>' +
    '<span class="count" id="count"><b>' + ROWS.length + "</b> shown</span></div>" +
    '<p class="barnote">Every filter takes more than one value. Within a filter they are OR, across filters they are AND.</p></div>');
  h.push('<div id="warn"></div>');
  regOrder.forEach(function (reg) {
    var secs = byReg[reg], ids = [], n = 0;
    Object.keys(secs).forEach(function (s) { secs[s].forEach(function (i) { ids.push(ROWS[i].id); n++; }); });
    ids.sort();
    h.push('<details class="reg"' + (n <= 40 ? " open" : "") + '><summary><span class="caret"></span>' +
      '<span class="rtitle">' + esc(reg) + '</span><span class="rsub">' + esc(META.subs[reg] || "") +
      " &middot; IDs " + esc(ids[0]) + " to " + esc(ids[ids.length - 1]) +
      '</span><span class="rn" data-rn>' + n + "</span></summary>");
    var keys = Object.keys(secs), multi = keys.length > 1;
    keys.forEach(function (s) {
      if (multi) h.push('<details class="sub"><summary><span class="caret"></span><span class="stitle">' +
        esc(s) + '</span><span class="rn" data-rn>' + secs[s].length + "</span></summary>");
      secs[s].forEach(function (i) { h.push(rowHTML(ROWS[i], i)); });
      if (multi) h.push("</details>");
    });
    h.push("</details>");
  });
  h.push('<div class="empty" id="none" hidden>Nothing matches those filters.</div>');
  h.push("<footer><p>" + esc(META.footer) + "</p></footer>");
  h.push('<div class="savebar" id="savebar" hidden></div>');
  document.getElementById("app").innerHTML = h.join("");
}

/* ---------------------------- filters ---------------------------- */
var rowEls, hay, MS, q, fu, fk, cnt, none;
function wireFilters() {
  rowEls = [].slice.call(document.querySelectorAll(".row"));
  hay = ROWS.map(function (x) {
    return (x.id + " " + x.desc + " " + (x.notes || "") + " " + x.owner_full + " " + x.category + " " + x.community +
      " " + x.sec + " " + x.lot + " " + x.state + " " + x.srctype).toLowerCase();
  });
  q = document.getElementById("q"); fu = document.getElementById("fu");
  fk = document.getElementById("fk"); cnt = document.getElementById("count");
  none = document.getElementById("none");
  var FIELD = { fp: "priority", fc: "category", fm: "community", fo: "owner_short" };
  MS = [].slice.call(document.querySelectorAll(".ms")).map(function (el) {
    return { el: el, field: FIELD[el.id], btn: el.querySelector(".ms__btn"),
      panel: el.querySelector(".ms__panel"), sel: el.querySelector(".ms__sel"),
      boxes: [].slice.call(el.querySelectorAll("input[type=checkbox]")) };
  });
  function lab(m) {
    var c = m.boxes.filter(function (b) { return b.checked; });
    m.sel.textContent = c.length === 0 ? "all" : (c.length === 1 ? c[0].value : c.length + " selected");
    m.el.classList.toggle("on", c.length > 0);
  }
  function closeAll(x) { MS.forEach(function (m) { if (m !== x) m.panel.hidden = true; }); }
  MS.forEach(function (m) {
    m.btn.addEventListener("click", function (ev) {
      ev.stopPropagation(); var o = m.panel.hidden; closeAll(m); m.panel.hidden = !o;
    });
    m.panel.addEventListener("click", function (ev) { ev.stopPropagation(); });
    m.boxes.forEach(function (b) { b.addEventListener("change", function () { lab(m); apply(); }); });
    m.el.querySelector(".ms__all").addEventListener("click", function () {
      m.boxes.forEach(function (b) { b.checked = true; }); lab(m); apply(); });
    m.el.querySelector(".ms__none").addEventListener("click", function () {
      m.boxes.forEach(function (b) { b.checked = false; }); lab(m); apply(); });
    lab(m);
  });
  document.addEventListener("click", function () { closeAll(null); });
  [q, fu, fk].forEach(function (el) { el.addEventListener("input", apply); });
  document.getElementById("reset").onclick = function () {
    q.value = ""; fu.checked = false; fk.checked = false;
    MS.forEach(function (m) { m.boxes.forEach(function (b) { b.checked = false; }); lab(m); m.panel.hidden = true; });
    document.querySelectorAll("details.sub").forEach(function (s) { s.open = false; });
    apply();
  };
  var exp = false;
  document.getElementById("expand").onclick = function (ev) {
    exp = !exp; document.querySelectorAll("details").forEach(function (s) { s.open = exp; });
    ev.target.textContent = exp ? "Collapse all" : "Expand all";
  };
}
function apply() {
  var t = q.value.trim().toLowerCase(), u = fu.checked, k = fk.checked;
  var sets = MS.map(function (m) {
    return [m.field, m.boxes.filter(function (b) { return b.checked; }).map(function (b) { return b.value; })];
  }).filter(function (p) { return p[1].length; });
  var n = 0;
  rowEls.forEach(function (r) {
    var i = +r.dataset.i, x = ROWS[i];
    var ok = (!t || hay[i].indexOf(t) >= 0) && (!u || x.owner_short === "Unassigned") &&
             (!k || allFor(x.id).length > 0);
    if (ok) for (var j = 0; j < sets.length; j++) {
      if (sets[j][1].indexOf(x[sets[j][0]]) < 0) { ok = false; break; }
    }
    r.hidden = !ok; if (ok) n++;
  });
  var act = t || u || k || sets.length > 0;
  document.querySelectorAll("details.sub").forEach(function (s) {
    var v = [].slice.call(s.querySelectorAll(".row")).filter(function (r) { return !r.hidden; }).length;
    s.hidden = v === 0; s.querySelector("[data-rn]").textContent = v; if (v && act) s.open = true;
  });
  document.querySelectorAll("details.reg").forEach(function (s) {
    var v = [].slice.call(s.querySelectorAll(".row")).filter(function (r) { return !r.hidden; }).length;
    s.hidden = v === 0; s.querySelector("summary [data-rn]").textContent = v; if (v && act) s.open = true;
  });
  cnt.innerHTML = "<b>" + n + "</b> shown"; none.hidden = n > 0;
}

/* ---------------------------- clipboard ---------------------------- */
function copy(s) {
  try { navigator.clipboard.writeText(s); } catch (e) {
    var t = document.createElement("textarea"); t.value = s;
    document.body.appendChild(t); t.select();
    try { document.execCommand("copy"); } catch (_) {} t.remove();
  }
}
function flash(el, txt) {
  var o = el.innerHTML; el.classList.add("copied"); el.textContent = txt;
  setTimeout(function () { el.classList.remove("copied"); el.innerHTML = o; }, 900);
}
var toastT;
function toast(msg) {
  var el = document.getElementById("toast");
  if (!el) { el = document.createElement("div"); el.id = "toast"; el.className = "toast"; document.body.appendChild(el); }
  el.textContent = msg; el.hidden = false;
  clearTimeout(toastT); toastT = setTimeout(function () { el.hidden = true; }, 3200);
}

/* ---------------------------- the modal ---------------------------- */
var openId = null;
function commentHTML(c, id, idx, isPend) {
  return '<div class="cm st-' + esc(c.state) + '"><div class="cmh">' +
    '<span class="cmt">' + esc(c.ts) + '</span>' +
    '<span class="cms">' + esc(c.state) + "</span>" +
    (isPend ? '<button class="cmdel" data-del="' + idx + '">remove</button>' : "") +
    '</div><div class="cmb">' + esc(c.text) + "</div></div>";
}
function openModal(id) {
  var r = null;
  for (var i = 0; i < ROWS.length; i++) if (ROWS[i].id === id) { r = ROWS[i]; break; }
  if (!r) return;
  openId = id;
  var saved = COM[id] || [], pend = PEND[id] || [];
  var log = saved.map(function (c) { return commentHTML(c, id, -1, false); }).join("") +
            pend.map(function (c, k) { return commentHTML(c, id, k, true); }).join("");
  if (!log) log = '<p class="nocm">No comments yet on this item.</p>';
  var m = document.createElement("div");
  m.className = "mask"; m.id = "mask";
  m.innerHTML = '<div class="modal" role="dialog" aria-modal="true">' +
    '<div class="mhead"><span class="rid">' + esc(r.id) + "</span>" +
    '<span class="pill ' + (PCLASS[r.priority] || "p-open") + '">' + esc(PLABEL[r.priority] || r.priority) + "</span>" +
    "<h3>" + esc(trim(r.desc, 320)) + "</h3>" +
    '<button class="mx" id="mclose" aria-label="Close">&times;</button></div>' +
    '<div class="mmeta"><dl>' +
      "<dt>Register</dt><dd>" + esc(r.reg) + " &middot; " + esc(r.sec) + "</dd>" +
      "<dt>Owner</dt><dd>" + esc(r.owner_full || r.owner_short) + "</dd>" +
      "<dt>Status</dt><dd>" + esc(r.state || "open") + "</dd>" +
      (r.community ? "<dt>Community</dt><dd>" + esc(r.community) + "</dd>" : "") +
    "</dl></div>" +
    (r.notes ? '<div class="mnotes"><h4>Register notes</h4><p>' + esc(r.notes) + "</p></div>" : "") +
    '<div class="mlog"><h4>Comment history</h4>' + log + "</div>" +
    '<div class="madd"><h4>Add a comment</h4>' +
    '<textarea id="cnew" placeholder="What changed, what you decided, who owns it&hellip;"></textarea>' +
    '<div class="mact"><button class="btn pri" id="cadd">Add comment</button>' +
    '<button class="btn" id="ccopy">Copy this item’s open comments</button>' +
    '<span class="hint">Ctrl or Cmd + Enter to add</span></div></div></div>';
  document.body.appendChild(m);
  var ta = document.getElementById("cnew");
  ta.focus();
  m.addEventListener("click", function (ev) { if (ev.target === m) closeModal(); });
  document.getElementById("mclose").onclick = closeModal;
  document.getElementById("cadd").onclick = addComment;
  document.getElementById("ccopy").onclick = function () {
    var o = openFor(id);
    if (!o.length) { toast("No open comments on " + id + "."); return; }
    copy(o.map(function (c) { return id + ": " + c.text; }).join("\n"));
    toast("Copied " + o.length + " comment" + (o.length > 1 ? "s" : "") + " for " + id + ".");
  };
  ta.addEventListener("keydown", function (ev) {
    if ((ev.metaKey || ev.ctrlKey) && ev.key === "Enter") { ev.preventDefault(); addComment(); }
  });
  m.querySelectorAll("[data-del]").forEach(function (b) {
    b.onclick = function () {
      var k = +b.dataset.del;
      PEND[openId].splice(k, 1);
      if (!PEND[openId].length) delete PEND[openId];
      savePend(); var id2 = openId; closeModal(); refreshRow(id2); openModal(id2);
    };
  });
}
function addComment() {
  var ta = document.getElementById("cnew"), txt = ta.value.trim();
  if (!txt) { ta.focus(); return; }
  (PEND[openId] = PEND[openId] || []).push({ ts: stamp(), text: txt, state: "pending" });
  savePend();
  var id = openId; closeModal(); refreshRow(id); openModal(id);
  toast("Added. Not saved to the page until you hit Save.");
}
function closeModal() {
  var m = document.getElementById("mask");
  if (m) m.remove();
  openId = null;
}
function refreshRow(id) {
  var i = -1;
  for (var k = 0; k < ROWS.length; k++) if (ROWS[k].id === id) { i = k; break; }
  if (i < 0) return;
  var el = document.querySelector('.row[data-i="' + i + '"]');
  if (el) {
    var wrap = document.createElement("div");
    wrap.innerHTML = rowHTML(ROWS[i], i);
    var nu = wrap.firstChild;
    nu.hidden = el.hidden;
    el.parentNode.replaceChild(nu, el);
    rowEls = [].slice.call(document.querySelectorAll(".row"));
  }
  updateBar();
}

/* ---------------------------- save ---------------------------- */
var ART = null, READONLY = false;
function updateBar() {
  var n = pendCount(), bar = document.getElementById("savebar");
  var tot = 0; for (var k in COM) tot += COM[k].length; tot += n;
  var el = document.getElementById("cmtot"); if (el) el.textContent = tot;
  if (!n) { bar.hidden = true; bar.innerHTML = ""; return; }
  bar.hidden = false;
  bar.innerHTML = "<b>" + n + " comment" + (n > 1 ? "s" : "") + " not saved yet</b>" +
    '<span class="sp"></span>' +
    '<button class="btn" id="bdiscard">Discard unsaved</button>' +
    '<button class="btn" id="bcopy">Copy open comments</button>' +
    '<button class="btn pri" id="bsave"' + (READONLY ? " disabled" : "") + ">Save to the page</button>";
  document.getElementById("bcopy").onclick = copyOpen;
  document.getElementById("bdiscard").onclick = function () {
    if (!confirm("Discard " + pendCount() + " unsaved comment(s)?")) return;
    var ids = Object.keys(PEND); PEND = {}; savePend();
    ids.forEach(refreshRow); updateBar(); toast("Unsaved comments discarded.");
  };
  document.getElementById("bsave").onclick = doSave;
}
function copyOpen() {
  var lines = [];
  ROWS.forEach(function (r) {
    openFor(r.id).forEach(function (c) { lines.push(r.id + ": " + c.text); });
  });
  if (!lines.length) { toast("Nothing open to copy."); return; }
  copy(lines.join("\n"));
  toast("Copied " + lines.length + " open comment" + (lines.length > 1 ? "s" : "") + ". Paste into chat.");
}
function mergePending() {
  var out = {};
  for (var k in COM) out[k] = COM[k].slice();
  for (var id in PEND) {
    out[id] = (out[id] || []).concat(PEND[id].map(function (c) {
      return { ts: c.ts, text: c.text, state: "open" };
    }));
  }
  return out;
}
function buildDoc(comments) {
  var b64 = document.getElementById("tpl").textContent.trim();
  var tpl = decodeURIComponent(escape(atob(b64)));
  var data = JSON.stringify({ meta: META, rows: ROWS, comments: comments })
    .replace(/</g, "\\u003c");
  /* markers are assembled at runtime so this source does not itself contain
     them - the builder replaces every literal occurrence in the template. */
  var mT = "__TPL" + "_B64__", mD = "__DATA" + "_JSON__";
  var inner = tpl.replace(mT, function () { return b64; })
                 .replace(mD, function () { return data; });
  return '<!doctype html><html lang="en"><head><meta charset="utf-8">' +
    '<meta name="viewport" content="width=device-width,initial-scale=1"></head><body>' +
    inner + "</body></html>";
}
function doSave() {
  var btn = document.getElementById("bsave");
  if (!ART) { toast("Saving is not available in this view. Use Copy open comments instead."); return; }
  btn.disabled = true; btn.textContent = "Saving…";
  var merged = mergePending();
  var doc;
  try { doc = buildDoc(merged); }
  catch (e) { btn.disabled = false; btn.textContent = "Save to the page"; toast("Could not build the new version: " + e.message); return; }
  try { sessionStorage.setItem(VIEW_KEY, JSON.stringify({ y: window.scrollY })); } catch (e) {}
  ART.publish(doc).then(function () {
    PEND = {}; savePend();
    toast("Saved. Reloading to the new version…");
  }).catch(function (err) {
    var code = (err && err.code) || "upstream_error";
    btn.disabled = false; btn.textContent = "Save to the page";
    if (code === "conflict") { toast("Someone else published first. Your comments are kept here; the page is reloading."); return; }
    if (code === "not_writer" || code === "not_granted" || code === "not_declared" ||
        code === "capability_disabled" || code === "capability_removed" || code === "consent_required") {
      READONLY = true; showWarn("This view can read the board but not save to it. Your comments stay in this browser — use <b>Copy open comments</b> to get them out.");
      updateBar(); return;
    }
    if (code === "too_large") { toast("The page is too large to save. Ask Claude to rebuild it."); return; }
    if (code === "rate_limited") { toast("Saving too often. Wait a moment and try again."); return; }
    toast("Save failed (" + code + "). Your comments are still here — use Copy open comments.");
  });
}
function showWarn(html) {
  var w = document.getElementById("warn");
  if (w) w.innerHTML = '<div class="warnbar">' + html + "</div>";
}

/* ---------------------------- boot ---------------------------- */
render();
wireFilters();
updateBar();
apply();

document.addEventListener("click", function (ev) {
  var cb = ev.target.closest(".cbtn");
  if (cb) { ev.stopPropagation(); openModal(cb.dataset.c); return; }
  var id = ev.target.closest(".rid");
  if (id && !ev.target.closest(".mhead")) { copy(id.textContent.trim()); flash(id, "copied"); return; }
  if (id) { copy(id.textContent.trim()); return; }
  var cq = ev.target.closest(".cpq");
  if (cq) { copy(cq.dataset.q); flash(cq, "copied"); }
});
document.addEventListener("keydown", function (ev) {
  if (ev.key === "Escape") { if (document.getElementById("mask")) closeModal(); }
});
window.addEventListener("beforeunload", function (ev) {
  if (pendCount()) { ev.preventDefault(); ev.returnValue = ""; }
});
try {
  var v = JSON.parse(sessionStorage.getItem(VIEW_KEY) || "null");
  if (v && typeof v.y === "number") { window.scrollTo(0, v.y); sessionStorage.removeItem(VIEW_KEY); }
} catch (e) {}

if (window.claude && typeof window.claude.use === "function") {
  window.claude.use("artifact").then(function (a) {
    ART = a || null;
    if (!ART) { READONLY = true; showWarn("Saving is not available in this view, so comments stay in this browser only. <b>Copy open comments</b> still works."); }
    updateBar();
  }).catch(function () { READONLY = true; updateBar(); });
} else {
  READONLY = true;
  showWarn("This copy of the board is running outside claude.ai, so it cannot save. Comments stay in this browser.");
}
