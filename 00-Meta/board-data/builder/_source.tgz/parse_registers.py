# -*- coding: utf-8 -*-
"""Parse the five Parakeet registers into board rows.

Header-driven: every markdown table is read by its own header row, so a table
with six columns and a table with five both map correctly. The 2026-09-01
mapping defect came from assuming a fixed column order.
"""
import io, os, re, json, html, urllib.parse

VAULT = os.environ.get("VAULT", "/mnt/user-data/uploads/My Brain")

ID_RE = re.compile(r"`((?:CM|PD|KP|TD|PF)-\d{2,4})`")
WIKI  = re.compile(r"\[\[([^\]|]+)(?:\\?\|([^\]]+))?\]\]")

def clean(t):
    t = WIKI.sub(lambda m: (m.group(2) or m.group(1).split("/")[-1]), t or "")
    t = re.sub(r"~~([^~]*)~~", r"\1", t)
    t = t.replace("**","").replace("*","").replace("`","")
    t = re.sub(r"<[^>]+>", "", t)
    return re.sub(r"\s+", " ", t).strip()

NOTE_SPLIT = re.compile(r"\s+(?=(?:~~)?\*\*(?:20\d\d-\d\d-\d\d|CLOSED|FIXED|RESOLVED|CORRECTION|Sharpened|Deferred|Recorded)\b)")
def split_notes(cell):
    """Register cells accumulate dated dispositions after the finding itself.
    The finding is what belongs on a board row; the dispositions belong in the
    popup. Split on the first bolded date or disposition keyword."""
    m = NOTE_SPLIT.search(cell or "")
    if not m:
        return cell, ""
    return cell[:m.start()], cell[m.end():]

def split_row(ln):
    body = ln.strip()
    if not body.startswith("|"): return None
    body = body.strip("|").replace("\\|", "\x00")
    return [c.strip().replace("\x00", "|") for c in body.split("|")]

def is_sep(cells):
    return all(set(c) <= set("-: ") and c for c in cells)

CATS = [
 ("Titles",      r"\btitle|retitle|dmv|mso\b"),
 ("Legal",       r"\blegal|counsel|litigat|lawsuit|eviction|attorney|compliance|statut|lien\b"),
 ("Finance",     r"\baccount|invoice|payabl|receivab|budget|ap\b|ar\b|payroll|gl\b|ledger|ramp|wire|audit|tax|noi|revenue|reserve|capital\b"),
 ("Systems & data", r"\bsharepoint|rent manager|warehouse|data|report|dashboard|power automate|entra|permission|migrat|system|integrat|api|onedrive|teams\b"),
 ("People",      r"\bhire|hr\b|handbook|onboard|employee|manager|staff|training|turnover|headcount\b"),
 ("Utilities",   r"\butilit|water|sewer|septic|electric|meter|boil|aerator|lift station|propane\b"),
 ("Construction",r"\brehab|construct|permit|set\b|demo|lot prep|skirting|roof|punch|make ready|capex|home order\b"),
 ("Collections", r"\bcollect|delinquen|past due|balance|over 90\b"),
 ("Sales & leasing", r"\bsale|lease|listing|prospect|market rent|infill|occupanc|mhvillage\b"),
 ("Resident",    r"\bresident|tenant|homeowner|renter|complaint\b"),
 ("Regulatory",  r"\bregulat|state filing|division|licen|inspection|esg|jadian\b"),
 ("Amenities",   r"\bamenit|pool|clubhouse|playground|shuffleboard|landscap|signage\b"),
]
def categorise(text):
    t = text.lower()
    for name, pat in CATS:
        if re.search(pat, t): return name
    return "Uncategorised"

OWNER_CANON = [
 (r"austin", "Austin Berk"), (r"jon\b|wyss", "Jon Wyss"), (r"natalie|magurne", "Natalie Magurne"),
 (r"leslie|croft", "Leslie Croft"), (r"john clark", "John Clark"), (r"zach|schwartz", "Zach Schwartz"),
 (r"berman|david", "David Berman"), (r"demetria|loukas", "Demetria Loukas"), (r"albert", "Albert"),
 (r"moe|mehmood", "Moe Mehmood"), (r"melanie", "Melanie Sanchez-Soto"),
 (r"ashlyne|godinez", "Ashlyne Godinez"), (r"liznette|santiago", "Liznette Santiago"),
 (r"counsel|wallack|gunster|jadian", "Outside counsel"),
]
def owner_short(full):
    f = (full or "").strip()
    if not f or re.match(r"^[-—–]$", f) or re.search(r"unassigned|no owner|nobody", f, re.I):
        return "Unassigned"
    low = f.lower()
    for pat, name in OWNER_CANON:
        if re.search(pat, low): return name
    return re.split(r"[,/;(—-]", f)[0].strip()[:40] or "Unassigned"

def priority(reg, risk, state, section, desc):
    s = (state or "").lower()
    if "closed" in s or "resolved" in s: return "Closed"
    if reg == "Parked decisions": return "Awaiting your ruling"
    if "blocked" in s: return "Blocked"
    if re.search(r"decided.*(not action|never (done|actioned))", s): return "Decided, never actioned"
    r = (risk or "").lower()
    if "critical" in r or re.search(r"tier 1\b", (section or "").lower()): return "Critical (stated)"
    if "high" in r: return "High (stated)"
    if re.search(r"priority queue|tier [234]\b", (section or "").lower()): return "High (ledger)"
    if "deferred" in s or "waiting" in s: return "Open"
    return "Open"

def community_of(text):
    m = re.search(r"60-Communities/([a-z0-9\-]+)", text or "")
    if m and m.group(1) not in ("open-items","portfolio","regions","lots","activity","_model"):
        return m.group(1).replace("-", " ").title()
    return ""

def regurl(path):
    return "obsidian://open?vault=My%20Brain&file=" + urllib.parse.quote(path, safe="")

# ------------------------------------------------------------------ tables
def parse_table_register(relpath, regname, prefix, idcol_hint=None):
    p = os.path.join(VAULT, relpath)
    lines = io.open(p, encoding="utf-8").read().split("\n")
    out, section, headers = [], "", None
    for ln in lines:
        if ln.startswith("#"):
            section = clean(ln.lstrip("# ").strip()); headers = None; continue
        cells = split_row(ln)
        if cells is None:
            continue   # a blank line inside a table must NOT clear the header
        if is_sep(cells): continue
        joined = " | ".join(cells)
        if not ID_RE.search(joined):
            # candidate header row
            low = [c.lower() for c in cells]
            if any(h in low for h in ("item","finding","decision","#")):
                headers = [c.strip() for c in cells]
            continue
        rid = ID_RE.search(joined).group(1)
        if not rid.startswith(prefix): continue
        h = headers if headers and len(headers) == len(cells) else None
        def pick(*names):
            if not h: return ""
            for n in names:
                for i, hd in enumerate(h):
                    if hd.lower().strip() == n: return cells[i]
            for n in names:
                for i, hd in enumerate(h):
                    if n in hd.lower(): return cells[i]
            return ""
        desc = pick("item","finding","decision")
        if not desc:
            # fall back: the cell carrying the ID
            for c in cells:
                if ID_RE.search(c): desc = c; break
        desc, notes = split_notes(ID_RE.sub("", desc))
        desc = re.sub(r"^P\d+\s+", "", clean(desc)).strip()
        notes = clean(notes)
        owner = clean(pick("owner"))
        state = clean(pick("status"))
        risk  = clean(pick("risk","priority","confidence"))
        extra = " ".join(clean(pick(n)) for n in ("why it is here","what it blocks","context","where","raised"))
        blob  = " ".join(cells)
        mu = re.search(r"\((https?://[^\s)]+)\)", blob)
        turl = mu.group(1) if mu else ""
        if not owner and h is None:
            owner = ""
        out.append(dict(id=rid, reg=regname, sec=section, desc=desc, notes=notes, owner_full=owner or "Unassigned",
                        state=state or "open", risk=risk, extra=extra,
                        file=relpath, community=community_of(blob), age=None, lot="", srcurl=turl, srctype=""))
    return out

# ------------------------------------------------------------ commitments
def parse_commitments(relpath="00-Meta/commitments.md"):
    lines = io.open(os.path.join(VAULT, relpath), encoding="utf-8").read().split("\n")
    out, section, cur = [], "", None
    for ln in lines:
        if ln.startswith("## "):
            section = clean(ln[3:]); continue
        m = re.match(r"^###\s+(\d+)\.\s+(.*)$", ln)
        if m:
            n = int(m.group(1))
            cur = dict(id="CM-%02d" % n, reg="Commitments", sec=section or "Active",
                       desc=clean(re.sub(r"\s*[-—]\s*\*\*CLOSED.*$", "", m.group(2))), notes="",
                       owner_full="Unassigned", state="open", risk="", extra="",
                       file=relpath, community=community_of(m.group(2)), age=None, lot="",
                       srcurl="", srctype="")
            if "CLOSED" in m.group(2): cur["state"] = clean(re.search(r"\*\*(CLOSED[^*]*)\*\*", m.group(2)).group(1))
            out.append(cur); continue
        if cur is None: continue
        mo = re.match(r"^\s*-\s+\*\*Owner\*\*:\s*(.*)$", ln)
        if mo: cur["owner_full"] = clean(mo.group(1))
        ms = re.match(r"^\s*-\s+\*\*Status\*\*:\s*(.*)$", ln)
        if ms and "CLOSED" not in cur["state"]: cur["state"] = clean(ms.group(1))
        if not cur["community"]: cur["community"] = community_of(ln)
    # everything in Active outranks; risk from the page's own ranking language
    for r in out:
        if r["sec"].lower().startswith("active"): r["risk"] = "Critical"
    return out

# ------------------------------------------------- property follow-ups list
PF_RE = re.compile(r"^- `(PF-\d{4})`\s+`?(\d+)d`?\s+\*\*([^*]+)\*\*\s*·\s*([^·]*)·\s*(.*?)\s*—\s*(.*)$")
def parse_pf(relpath="60-Communities/open-items.md"):
    lines = io.open(os.path.join(VAULT, relpath), encoding="utf-8").read().split("\n")
    out, community = [], ""
    seen = set()
    for ln in lines:
        if ln.startswith("### "):
            community = clean(ln[4:]).split(" — ")[0].strip()
            continue
        m = PF_RE.match(ln.strip())
        if not m:
            continue
        rid, age, state, cat, lot, rest = m.groups()
        if rid in seen: continue
        seen.add(rid)
        owner = ""; src = ""
        mo = re.search(r"\*\(owner:\s*([^;)]*)(?:;\s*([^)]*))?\)\*", rest)
        if mo:
            owner = clean(mo.group(1)); src = clean(mo.group(2) or "")
            rest = rest[:mo.start()].strip()
        rest = re.sub(r"\[source\]\(https?://[^)]*\)", "", rest).strip()
        url = ""
        mu = re.search(r"\((https?://[^\s)]+)\)", ln)   # scan the whole line: the link sits AFTER the owner block
        if mu: url = mu.group(1)
        out.append(dict(id=rid, reg="Property follow-ups",
                        sec=("Portfolio-wide and unattributed" if community.lower().startswith("portfolio") else community) or "Unfiled",
                        desc=clean(rest), notes="", owner_full=owner or "Unassigned", state=clean(state),
                        risk="", extra="", file=relpath,
                        community="" if community.lower().startswith("portfolio") else community,
                        age=int(age), lot=clean(lot) if lot.strip() not in ("-","") else "",
                        srcurl=url, srctype=src))
    return out

def build():
    rows = []
    rows += parse_commitments()
    rows += parse_table_register("00-Meta/parked-decisions.md", "Parked decisions", "PD")
    rows += parse_table_register("00-Meta/open-items.md", "Known problems", "KP")
    rows += parse_table_register("10-Business/eos/to-dos.md", "EOS to-dos", "TD")
    rows += parse_pf()
    for r in rows:
        r["category"] = categorise(r["desc"] + " " + r["extra"] + " " + r["sec"])
        r["owner_short"] = owner_short(r["owner_full"])
        r["unowned"] = r["owner_short"] == "Unassigned"
        r["priority"] = priority(r["reg"], r["risk"], r["state"], r["sec"], r["desc"])
        r["regurl"] = regurl(r["file"])
        if len(r["owner_full"]) > 200: r["owner_full"] = r["owner_full"][:200]
    return rows

if __name__ == "__main__":
    rows = build()
    import collections
    print("total", len(rows))
    print(collections.Counter(r["reg"] for r in rows))
    print(collections.Counter(r["priority"] for r in rows))
    print("unowned", sum(1 for r in rows if r["unowned"]))
    for rid in ("TD-0003","TD-0004","KP-0001","KP-0010","CM-07","PD-01","PF-0001","TD-0327"):
        for r in rows:
            if r["id"] == rid:
                print(rid, "|", r["desc"][:80], "|| owner:", r["owner_full"][:50], "|| pr:", r["priority"], "|| st:", r["state"][:40])
                break
        else: print(rid, "MISSING")
