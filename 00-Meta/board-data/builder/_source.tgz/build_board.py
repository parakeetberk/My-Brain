# -*- coding: utf-8 -*-
"""Rebuild the Open Board page from the five registers.

    VAULT="$HOME/mnt/My Brain" python3 build_board.py [--comments comments.json]

The page renders its rows from a JSON block rather than from pre-rendered
markup, which is what lets it republish ITSELF when Austin saves a comment.
It carries a base64 copy of its own template so a self-publish is a fixed
point: only the data block changes.

Comment history is never generated here. It is read from `comments.json`
(extracted from the live artifact by `pull_comments.py`) and carried
through untouched, so a rebuild can never lose a comment.
"""
import io, os, re, sys, json, html, base64, collections
from parse_registers import build, VAULT

TODAY = "1 September 2026"
HERE = os.path.dirname(os.path.abspath(__file__))
def R(n): return io.open(os.path.join(HERE, n), encoding="utf-8").read()

STOP = set("the a an and or of to in on for with that this it is are was were be been at by from as "
           "into not no nothing needs need has have had which whose what who when where why how "
           "its their our his her them they we you i one two three still yet only also".split())
def search_phrase(desc):
    w = [x for x in re.findall(r"[A-Za-z0-9$,'.-]+", desc or "") if x.lower() not in STOP and len(x) > 2]
    return " ".join(w[:7])

SUBS = {
 "Commitments":        "What you owe and are owed at the corporate level",
 "Parked decisions":   "Waiting on your ruling. A row leaves when you rule, not when it ages",
 "Known problems":     "Findings about the business and about the Brain, ranked by risk",
 "EOS to-dos":         "Actions with a named owner, grouped for one-on-ones",
 "Property follow-ups":"Property-level follow-ups, by community",
}
REG_ORDER = ["Commitments", "Parked decisions", "Known problems", "EOS to-dos", "Property follow-ups"]

HOW = """
<div class="how">
  <h2>How the comment loop works</h2>
  <p><b>Every row has a Comment button next to Copy search.</b> It opens the item in full with its whole comment history, date stamped, oldest first. Add a note and it sits as <b>pending</b> in this browser until you hit <b>Save to the page</b>, which writes it into the board itself so it survives a reload and anyone with the link can see it.</p>
  <p><b>Save does not reach me.</b> Nothing wakes a cloud session when you type. So the button that actually moves work is <b>Copy open comments</b>: it puts every unactioned note on your clipboard as <code style="font-family:var(--mono)">KP-0001: your text</code>, one line per row. Paste that into chat and I write them into the registers, then rebuild this page with those comments marked <b>actioned</b>.</p>
  <p><b>A rebuild never wipes your comments.</b> The builder reads this page first and carries the history through. Three states, all visible in the popup: <b>pending</b> (in your browser only), <b>open</b> (saved here, waiting on me), <b>actioned</b> (written into the register).</p>
</div>
"""

FOOTER = ("%d rows from commitments, parked decisions, known problems, EOS to-dos and property "
          "follow-ups, 1 September 2026. IDs are written into the register files themselves, so they "
          "survive every rebuild. Owner, age, state and category come from the register that holds the "
          "row wherever it states them; category is inferred where no register states one and %d rows "
          "sit in Uncategorised rather than being forced. Priority is the source's own signal, never "
          "invented. The five registers do overlap in practice, so %d is a row count and not a count of "
          "distinct problems. Built by 00-Meta/board-data/builder/build_board.py, which reads every "
          "markdown table by its own header row.")

def main():
    comments = {}
    if "--comments" in sys.argv:
        cp = sys.argv[sys.argv.index("--comments") + 1]
        if os.path.exists(cp):
            comments = json.load(io.open(cp, encoding="utf-8"))
    elif os.path.exists(os.path.join(HERE, "comments.json")):
        comments = json.load(io.open(os.path.join(HERE, "comments.json"), encoding="utf-8"))

    rows = build()
    keys = ("id","reg","sec","desc","notes","owner_short","owner_full","category","community",
            "priority","state","lot","age","srcurl","srctype","regurl")
    out = []
    for r in rows:
        d = {k: r.get(k, "") for k in keys}
        d["q"] = search_phrase(d["desc"])
        d["desc"] = d["desc"][:700]
        d["notes"] = (d.get("notes") or "")[:1800]
        out.append(d)
    order = {n: i for i, n in enumerate(REG_ORDER)}
    out.sort(key=lambda r: (order.get(r["reg"], 99),))

    n_total = len(out)
    n_open = sum(1 for r in out if r["priority"] != "Closed")
    n_unowned = sum(1 for r in out if r["owner_short"] == "Unassigned" and r["priority"] != "Closed")
    n_hot = sum(1 for r in out if r["priority"] in ("Critical (stated)", "Awaiting your ruling"))
    n_closed = n_total - n_open
    n_uncat = sum(1 for r in out if r["category"] == "Uncategorised")

    meta = dict(built=TODAY, total=n_total, open=n_open, unowned=n_unowned, hot=n_hot,
                closed=n_closed, subs=SUBS, how=HOW,
                footer=FOOTER % (n_total, n_uncat, n_total))

    head = R("template_head.html").replace("__BOARD_CSS__", R("board.css"))
    tpl = (head +
           '\n<div class="wrap" id="app"></div>\n' +
           '<script id="tpl" type="text/plain">__TPL_B64__</script>\n' +
           '<script id="board" type="application/json">__DATA_JSON__</script>\n' +
           "<script>\n" + R("template_app.js") + "\n</script>\n")

    b64 = base64.b64encode(tpl.encode("utf-8")).decode("ascii")
    data = json.dumps(dict(meta=meta, rows=out, comments=comments),
                      ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c")
    doc = tpl.replace("__TPL_B64__", lambda_free(b64)).replace("__DATA_JSON__", lambda_free(data))

    io.open(os.path.join(HERE, "open-board.html"), "w", encoding="utf-8").write(doc)
    json.dump(out, io.open(os.path.join(HERE, "open-board-2026-09-01.json"), "w", encoding="utf-8"),
              ensure_ascii=False)
    ncom = sum(len(v) for v in comments.values())
    print("rows %d  open %d  unowned %d  comments carried %d  bytes %d"
          % (n_total, n_open, n_unowned, ncom, len(doc)))

def lambda_free(s):
    """str.replace treats no characters specially, but re-based helpers do.
    Kept explicit so nobody 'improves' this into re.sub and gets bitten by \\1."""
    return s

if __name__ == "__main__":
    main()
